package com.foro.hub.dto;

import java.time.LocalDate;

public record DatosRespuestaTopico(
    Long id,
    String titulo,
    String mensaje,
    LocalDate fechaCreacion,
    String status,
    String autor,
    String curso
) {}
