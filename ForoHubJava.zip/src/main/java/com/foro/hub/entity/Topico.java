package com.foro.hub.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class Topico {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String titulo;
    private String mensaje;
    private LocalDate fechaCreacion;
    private String status;
    private String autor;
    private String curso;

    public Topico() {}

    public Topico(String titulo, String mensaje, String autor, String curso) {
        this.titulo = titulo;
        this.mensaje = mensaje;
        this.autor = autor;
        this.curso = curso;
        this.status = "ACTIVO";
        this.fechaCreacion = LocalDate.now();
    }

    public void actualizar(String titulo, String mensaje, String curso) {
        this.titulo = titulo;
        this.mensaje = mensaje;
        this.curso = curso;
    }

    // Getters y setters omitidos por brevedad
}
