package com.foro.hub.controller;

import com.foro.hub.dto.*;
import com.foro.hub.entity.Topico;
import com.foro.hub.repository.TopicoRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/topicos")
public class TopicoController {

    @Autowired
    private TopicoRepository repository;

    @PostMapping
    public ResponseEntity<?> registrar(@RequestBody @Valid DatosRegistroTopico datos) {
        Optional<Topico> existente = repository.findByTituloAndMensaje(datos.titulo(), datos.mensaje());
        if (existente.isPresent()) return ResponseEntity.badRequest().body("Tópico duplicado");

        Topico topico = new Topico(datos.titulo(), datos.mensaje(), datos.autor(), datos.curso());
        repository.save(topico);
        return ResponseEntity.ok(new DatosRespuestaTopico(topico.getId(), topico.getTitulo(),
                topico.getMensaje(), topico.getFechaCreacion(), topico.getStatus(),
                topico.getAutor(), topico.getCurso()));
    }

    @GetMapping
    public ResponseEntity<?> listar(@PageableDefault(size = 10, sort = "fechaCreacion") Pageable pageable) {
        return ResponseEntity.ok(
            repository.findAll(pageable).map(t ->
                new DatosRespuestaTopico(t.getId(), t.getTitulo(), t.getMensaje(), t.getFechaCreacion(),
                                         t.getStatus(), t.getAutor(), t.getCurso())
            )
        );
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> detalle(@PathVariable Long id) {
        return repository.findById(id)
                .map(t -> ResponseEntity.ok(
                        new DatosRespuestaTopico(t.getId(), t.getTitulo(), t.getMensaje(), t.getFechaCreacion(),
                                                 t.getStatus(), t.getAutor(), t.getCurso())))
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(@PathVariable Long id, @RequestBody @Valid DatosActualizarTopico datos) {
        Optional<Topico> existente = repository.findById(id);
        if (existente.isEmpty()) return ResponseEntity.notFound().build();

        Topico topico = existente.get();
        topico.actualizar(datos.titulo(), datos.mensaje(), datos.curso());
        repository.save(topico);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id) {
        Optional<Topico> existente = repository.findById(id);
        if (existente.isEmpty()) return ResponseEntity.notFound().build();

        repository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
